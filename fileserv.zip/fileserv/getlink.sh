#!/usr/bin/env bash

curl -s -N http://127.0.0.1:4040/api/tunnels | grep -o [0-9]\\.tcp\\.eu\\.ngrok\\.io:[0-9][0-9][0-9][0-9][0-9]
