#!/usr/bin/env bash
apt update
apt upgrade -y
apt install python3 python3-pip curl tar 
pip3 install colorama requests --break-system-package
python3 ngrokdown.py
user=$(whoami)
mkdir -p /home/$whoami/.config/ngrok
mkdir -p /root/.config/ngrok
cp -r core/ngrok.yml /home/$whoami/.config/ngrok/
cp -r core/ngrok.yml /root/.config/ngrok/
