#!/usr/bin/env python3

from colorama import Fore
from os import system as st
class color():
    R = Fore.RED
    G = Fore.GREEN
    B = Fore.BLUE
    Y = Fore.YELLOW
    RESET = Fore.RESET

def banner():
    st("echo '╔═══╗╔╗───╔═══╗'| lolcat")
    st("echo '║╔══╝║║───║╔═╗║'| lolcat")
    st("echo '║╚══╦╣║╔══╣╚══╦══╦═╦╗╔╗'| lolcat")
    st("echo '║╔══╬╣║║║═╬══╗║║═╣╔╣╚╝║'| lolcat")
    st("echo '║║──║║╚╣║═╣╚═╝║║═╣║╚╗╔╝'| lolcat")
    st("echo '╚╝──╚╩═╩══╩═══╩══╩╝─╚╝ '| lolcat")
    print(color.G + "Author: Freddy Phoenix Mills")
    print(color.G + "Version: 1.0")
    print(color.G + "Email: phoenixgibson007@gmail.com" + color.RESET)
