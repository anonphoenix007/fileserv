#!/usr/bin/env python3
from core.color import color
from core.color import banner
import http.server
import os
import sys
import time
import requests as rq
#from color import cols
banner()

def serve_linuz():
    while True:
       path = input(color.B + "Enter the path you want to serve VIA HTTP >>>" + color.RESET)
       if os.path.isdir(path):
           print(color.G + "[*] Directory exist,exceeding....." + color.RESET)
           break
       else:
          print(color.R + "No such Directory,Retry please" + color.RESET)
    portno = int(input(color.Y + "Enter your desired Port number >>> "))
    internet = input(color.G + "[?] Do you want to use internet(Y/N(lowercase only))>> ")
    if internet == "y":
       try:
          rq.get("https://github.com")
       except Exception:
          print(color.R + "No internet connection detected,exiting....")
          exit()
       os.system("killall ngrok >/dev/null 2>&1")
       os.system("ngrok tcp %s > /dev/null 2>&1 &" %(portno))
       time.sleep(5)
       print(color.G + "[*] Your Ngrok generated link is 👇👇👇👇👇👇👇👇")
       os.system("bash getlink.sh")
       os.system("python3 server.py %s --directory %s" % (portno, path))
    elif internet == "n":
           os.system("python3 server.py %s --directory %s" % (portno, path))
    else:
           print("Invalid option selected")

serve_linuz()
